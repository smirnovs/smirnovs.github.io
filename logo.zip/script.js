const form = document.forms.register;

const namePattern = form.elements.name.pattern;

const emaleForm = document.forms.name;
const phoneForm = document.forms.name;
const siteForm = document.forms.name;

console.log(namePattern);
