# [Homework](https://smirnovs.github.io/smirnovs.github.io/)
* Version: 0.1. 